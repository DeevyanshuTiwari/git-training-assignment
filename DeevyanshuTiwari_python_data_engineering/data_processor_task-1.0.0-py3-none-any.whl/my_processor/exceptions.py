
class InvalidMemberDataError(Exception):
    """Raised when a member record contains malformed data
    (bad name, email, or phone number)."""
    pass